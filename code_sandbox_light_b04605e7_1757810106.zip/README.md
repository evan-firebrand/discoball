# 🕺 Disco Ball Experience

A realistic 3D disco ball simulation built with Three.js that models real-world lighting physics including pinspot light distance, brightness, angle, speed, and ball size effects on reflections.

## ✨ Current Features

### Core Functionality
- **Configurable 3D Disco Ball**: 20-300 individual mirror facets with real-time regeneration
- **Visible Light Source**: See the actual light fixture pointing at the disco ball
- **Dynamic Pinspot Lighting**: Configurable spotlight with realistic shadows and visible light beam
- **Colored Reflections**: Light spots inherit the color of the spotlight (NEW!)
- **True Mirror Reflections**: Actual light spots projected on walls, ceiling, and floor
- **Physics-Based Calculations**: Real reflection vectors using incident and surface normals
- **Scalable Light Spots**: 10-100 simultaneous reflection spots that move as the ball rotates
- **Cone-Filtered Reflections**: Only facets within spotlight cone create reflections (NEW!)
- **3D Positioning**: Full X, Y, Z movement control for the disco ball
- **Ambient Lighting**: Adjustable room illumination for better visibility
- **Realistic Motor Animation**: Authentic rotation with speed variations and wobble (NEW!)
- **Dual Camera Modes**: Orbit controls and First-Person exploration with WASD + mouse look

### Dynamic Controls

#### Lighting Controls
- **Ball Rotation Speed**: 0-3 RPM with real-time adjustment
- **Light Distance**: 2-15 units from the disco ball
- **Light Intensity**: 0.1-3 brightness levels
- **Spot Angle**: 10°-90° light cone adjustment (affects reflection filtering)
- **Ambient Light**: 0-1.0 intensity for room visibility
- **Room Size**: 6-20 units - larger rooms create dimmer, smaller reflections (NEW!)

#### Light Source Properties
- **Light Color**: 8 preset colors (White, Red, Green, Blue, Magenta, Yellow, Cyan, Orange)
- **Light Angle**: 0°-360° horizontal positioning around disco ball
- **Light Height**: 1-8 units vertical positioning
- **Beam Softness**: 0-1.0 penumbra for soft/hard light edges
- **Show Light Beam**: Toggle visible light cone visualization

#### Disco Ball Configuration
- **Ball Size**: 0.5-3 scale multiplier (affects reflection spot size)
- **Mirror Facets**: 20-300 individual reflective surfaces (real-time regeneration)
- **Max Reflection Spots**: 10-100 simultaneous light projections
- **Motor Wobble**: Toggle realistic motor imperfections (NEW!)
- **Wobble Intensity**: 0-0.1 adjustment for motor irregularity (NEW!)

#### Performance & Analytics (NEW!)
- **Real-time FPS Counter**: Monitor rendering performance
- **Active Reflection Counter**: See live count of visible light spots
- **Performance Cost Indicator**: Real-time computational impact assessment
- **Quality Mode Selector**: High/Medium/Low performance optimization
- **Facet Count Display**: Monitor total mirror surfaces

#### Scene Management (NEW!)
- **Preset Scenes**: 5 built-in lighting configurations
  - Classic Disco, Intimate Lounge, High Energy Rave, Minimal Chic, Colorful Party
- **Save Custom Presets**: Save your favorite configurations with custom names
- **Persistent Storage**: Custom presets saved to browser localStorage
- **One-Click Reset**: Restore default settings instantly

#### Ball Position Controls
- **X Position**: -5 to +5 units (left/right)
- **Y Position**: -3 to +5 units (down/up) 
- **Z Position**: -5 to +5 units (forward/back)

### Visual Effects
- **True Disco Ball Reflections**: Light spots projected onto room surfaces (walls, floor, ceiling)
- **Ray-traced Reflections**: Each mirror facet calculates reflection vectors and surface intersections
- **Dynamic Spot Movement**: Reflection spots move realistically as the disco ball rotates
- **Advanced Intensity Calculations**: Brightness based on angle, distance, light intensity, and room size (NEW!)
- **Ball Size Effects**: Larger balls create larger reflection spots (NEW!)
- **Spotlight Cone Filtering**: Only illuminated facets create reflections (NEW!)
- **Surface Bounds Checking**: Reflections only appear within room boundaries
- **Motor Imperfections**: Speed variations, wobble, and micro-irregularities for authentic movement (NEW!)
- **Shadow Casting**: Realistic shadow mapping from the spotlight
- **Enhanced Room Environment**: Compact 10x10x10 room with ambient light support and complete reflection mapping
- **Immersive Exploration**: First-person mode lets you walk around the disco ball like in a real club
- **Professional Light Visualization**: See the actual light beam cone and adjust positioning like a real lighting technician

## 🚀 Currently Accessible URIs

- **Main Experience**: `index.html` - Full disco ball simulation
- **JavaScript Engine**: `js/disco-ball.js` - Core Three.js implementation

## 🎮 Controls

### Camera Controls
**Orbit Mode (Default):**
- **Left Click + Drag**: Orbit camera around the disco ball
- **Scroll Wheel**: Zoom in/out

**First-Person Mode:**
- **WASD**: Move forward/back/left/right
- **Mouse**: Look around (click to activate pointer lock)
- **Space**: Move up
- **Shift**: Move down
- **Scroll Wheel**: Disabled in FPS mode

### UI Controls Panel
Located in the top-left corner with real-time parameter adjustment:

**Lighting Controls:**
- Ball rotation speed slider (0-3 RPM)
- Light distance positioning (2-15 units)
- Light intensity control (0.1-3.0)
- Spotlight angle adjustment (10°-90°)
- Ambient light control (0-0.5)

**Disco Ball Configuration:**
- Ball size scaling (0.5-3.0x)
- Mirror facets count (20-300, real-time regeneration)
- Maximum reflection spots (10-100)

**Ball Position Controls:**
- X, Y, Z position sliders (-5 to +5 range)
- Real-time 3D positioning

**Camera Controls:**
- Camera mode selector (Orbit vs First-Person)
- Movement speed control (0.5-5.0x)
- Seamless mode switching with position reset

## 🔧 Technical Implementation

### Core Technologies
- **Three.js**: 3D rendering and scene management
- **WebGL**: Hardware-accelerated graphics
- **Orbit Controls**: Interactive camera navigation

### Physics Simulation
- **Ray-Surface Intersection**: Real-time calculation of reflection paths from each mirror facet
- **Surface Normal Calculations**: Proper reflection vectors using R = I - 2(I·N)N formula
- **Distance Falloff**: Intensity decreases realistically with reflection distance
- **Angle-Based Intensity**: Brightness varies based on incident light angle to facet surface
- **Spherical Coordinates**: Realistic mirror facet distribution on ball surface
- **Shadow Mapping**: PCF soft shadows for realistic lighting

### Data Models
```javascript
config: {
    ballSize: 1.5,          // Scale multiplier
    rotationSpeed: 1.0,     // RPM
    lightDistance: 6,       // Units from ball center
    lightIntensity: 1.5,    // Brightness level
    spotAngle: 30,          // Degrees
    mirrorFacets: 400       // Number of reflective surfaces
}
```

## 🎯 Features Not Yet Implemented

### Advanced Lighting Effects
- **Multiple Pinspot Lights**: Support for 2-4 simultaneous spotlights (architecture planned)
- **Light Movement**: Animated spotlight positioning and sweeping
- **Reflection Spot Trails**: Fading trails behind moving light spots

### Enhanced Disco Ball Physics
- **Facet Size Variation**: More realistic irregular mirror pieces
- **Material Properties**: Different reflectivity levels and surface types
- **Ball Suspension**: Chain or cable hanging mechanism

### Environmental Factors
- **Surface Materials**: Different wall textures (brick, mirror, fabric)  
- **Smoke/Haze Effects**: Particle systems for atmospheric enhancement
- **Music Visualization**: Audio-reactive lighting and rotation

### Advanced Controls
- **Preset Scenes**: Save/load lighting configurations
- **Animation Timeline**: Keyframe-based light choreography  
- **Performance Options**: Quality settings for different devices
- **VR Support**: WebXR integration for immersive experience

## 🔮 Recommended Next Steps

### Phase 1: Enhanced Lighting
1. **Wall Reflection Projections**: Calculate and render reflected light spots on room surfaces
2. **Multiple Light Sources**: Add 2-3 additional pinspots with independent controls
3. **Color Temperature**: Implement warm/cool lighting options

### Phase 2: Advanced Physics  
1. **Realistic Facet Geometry**: Non-uniform mirror piece shapes and sizes
2. **Caustic Lighting**: Advanced reflection calculations for more realistic light patterns
3. **Ball Suspension Animation**: Add natural hanging and swaying motion

### Phase 3: Environmental Enhancement
1. **Configurable Room Dimensions**: User-adjustable wall distances
2. **Atmospheric Effects**: Fog, haze, and particle systems
3. **Interactive Elements**: Clickable objects and dynamic scene changes

### Phase 4: Performance & Features
1. **Mobile Optimization**: Touch controls and performance scaling
2. **Audio Integration**: Music-reactive lighting and beat detection
3. **Social Features**: Share configurations and collaborative sessions

## 📱 Device Compatibility

- **Desktop**: Full feature set with mouse and keyboard controls
- **Mobile**: Touch-enabled camera controls (optimization pending)
- **Tablets**: Responsive UI scaling and touch interface
- **WebGL Requirements**: Modern browser with hardware acceleration

## 🎨 Artistic Goals

This simulation aims to recreate the nostalgic magic of classic disco balls by:
- Modeling authentic mirror facet behavior and light physics
- Providing intuitive controls to explore different lighting scenarios  
- Creating an immersive 3D environment that captures the disco era ambiance
- Serving as a foundation for more complex lighting installations and visualizations

## 🎉 Recently Implemented Features (Latest Update)

### ✅ Phase 1: Critical Physics Improvements 
- **Light Color → Reflection Color**: Reflection spots now inherit the spotlight color instead of always being white
- **Ball Size Impact on Reflections**: Larger disco balls create proportionally larger reflection spots
- **Light Position Verification**: Enhanced accuracy of light position calculations for reflections
- **Spot Angle Cone Filtering**: Only facets within the spotlight cone create reflections (major realism boost)

### ✅ Phase 2: High-Value Enhancements
- **Wall Distance/Room Size Impact**: Configurable room size (6-20 units) affects reflection brightness and size
- **Motor Wobble/Imperfect Rotation**: Realistic motor behavior with speed variations, wobble, and micro-irregularities

### ✅ Phase 3: Performance & User Experience
- **Real-time Performance Analytics**: FPS counter, reflection counter, computational cost assessment
- **Quality Mode Optimization**: High/Medium/Low performance modes with automatic setting adjustments
- **Scene Preset System**: 5 built-in presets plus custom save/load functionality with persistent storage

These improvements make the disco ball simulation significantly more realistic, user-friendly, and performance-optimized!

---

Experience the mesmerizing dance of light and reflection that has captivated audiences for decades! 🌟